import 'package:intl/intl.dart';
import '../../export.dart';

class HomeHeaderSection extends StatelessWidget {
  final bool isDarkMode;
  const HomeHeaderSection(this.isDarkMode, {super.key});

  @override
  Widget build(BuildContext context) {
    String formattedTime = DateFormat.jm().format(DateTime.now());
    String formattedDate =
        DateFormat('EEEE, MMMM d, yyyy').format(DateTime.now());
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      elevation: 1,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      child: SizedBox(
        width: double.infinity,
        height: 200,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(formattedTime,
                  style: Theme.of(context).textTheme.displayLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: ColorTheme.getPrimary(isDarkMode))),
              heightSizedBox(10.0),
              Text(formattedDate,
                  style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
        ),
      ),
    );
  }
}
