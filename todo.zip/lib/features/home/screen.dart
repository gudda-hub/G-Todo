import '../../export.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    bool isDarkMode = ref.watch(isDarkModeProvider);
    return Scaffold(
      appBar: header(ref, isDarkMode),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(children: [
            heightSizedBox(20.0),
            HomeHeaderSection(isDarkMode),
            heightSizedBox(30.0),
            GridView.builder(
                shrinkWrap: true,
                itemCount: taskTypes.length,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 10.0,
                    crossAxisSpacing: 10.0,
                    childAspectRatio: 1),
                itemBuilder: (context, index) {
                  return TaskTypeCard(
                    title: taskTypes[index].title,
                    icon: taskTypes[index].icon,
                    screen: taskTypes[index].widget,
                  );
                })
          ]),
        ),
      ),
      floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
      floatingActionButton: FloatingActionButton(
          onPressed: _createBtn,
          tooltip: 'Create Task',
          child: const Icon(Icons.add)),
    );
  }

  _createBtn() {
    navigatePush(const TaskCreateScreen());
  }

  AppBar header(WidgetRef ref, bool isDarkMode) {
    return AppBar(
      title: const Text('Quiz Master'),
      actions: [
        IconButton(
            onPressed: () {
              ref.read(isDarkModeProvider.notifier).state = !isDarkMode;
            },
            icon: const Icon(Icons.light_mode, size: 20)),
        widthSizedBox(10)
      ],
    );
  }
}
