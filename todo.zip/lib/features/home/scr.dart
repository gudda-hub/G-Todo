import '../../export.dart';

class TaskTypeCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget screen;
  const TaskTypeCard(
      {super.key,
      required this.title,
      required this.icon,
      required this.screen});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0.1,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
      child: InkWell(
          onTap: () {
            navigatePush(screen);
          },
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 40),
            heightSizedBox(10.0),
            Text(title, style: Theme.of(context).textTheme.bodyLarge)
          ])),
    );
  }
}

class TaskType {
  final String title;
  final IconData icon;
  final Widget widget;

  TaskType({required this.title, required this.icon, required this.widget});
}

List<TaskType> taskTypes = [
  TaskType(
      title: 'All Tasks', icon: Icons.list_alt, widget: const AllTaskScreen()),
  TaskType(
      title: 'Pending Tasks',
      icon: Icons.pending,
      widget: const PendingTaskScreen()),
  TaskType(
      title: 'Completed Tasks',
      icon: Icons.check_circle,
      widget: const CompletedTaskScreen()),
  TaskType(
      title: 'Today’s Tasks',
      icon: Icons.today,
      widget: const TodayTaskScreen()),
];
