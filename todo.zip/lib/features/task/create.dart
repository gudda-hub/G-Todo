import 'dart:developer';

import '../../export.dart';

class TaskCreateScreen extends ConsumerStatefulWidget {
  const TaskCreateScreen({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() =>
      _TaskCreateScreenState();
}

class _TaskCreateScreenState extends ConsumerState<TaskCreateScreen> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _selectedDateController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  String priority = '';
  String status = '';
  bool isComplete = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: TaskBackGroundPage(
        appBarTitle: "Add New Task",
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                heightSizedBox(26),
                TxtField(
                    txtModel: TxtModel(
                        labelText: "Task Title",
                        hintText: "Enter the task title",
                        controller: _titleController,
                        validator: (value) => value == null || value.isEmpty
                            ? "Title is required"
                            : null)),
                heightSizedBox(16),
                TxtField(
                    txtModel: TxtModel(
                        hintText: "Describe your task in detail",
                        maxLines: 8,
                        controller: _descriptionController,
                        validator: (value) => value == null || value.isEmpty
                            ? "Description is required"
                            : null)),
                heightSizedBox(16),
                TxtField(
                    txtModel: TxtModel(
                        labelText: "Select Due Date",
                        hintText: "Select Due Date",
                        controller: _selectedDateController,
                        keyboardType: TextInputType.number,
                        maxLines: 1,
                        validator: validateField,
                        suffixIcon: const Icon(Icons.calendar_today),
                        readOnly: true,
                        onTap: () async {
                          String getValue = await selectDateTime(context);
                          if (getValue.isNotEmpty) {
                            _selectedDateController.text = getValue;
                          }
                        })),
                heightSizedBox(16),
                DropDownBtn(priority, (value) {
                  setState(() {
                    priority = value!;
                  });
                }, hintTxt: "Select Priority", itemsList: priorityOptions),
                heightSizedBox(16),
                DropDownBtn(status, (value) {
                  setState(() {
                    status = value!;
                  });
                }, hintTxt: "Select Status", itemsList: statusOptions),
                heightSizedBox(16),
                DropDownBtn(isComplete ? 'Yes' : 'No', (value) {
                  setState(() {
                    isComplete = value == 'Yes' ? true : false;
                  });
                }, hintTxt: "Is Completed?", itemsList: isCompletedOptions),
                heightSizedBox(24),
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        elevation: 2,
                        fixedSize: const Size.fromHeight(50),
                        maximumSize:
                            Size.fromWidth(widthMediaQuery(context) * 1),
                        shape: const RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(10)))),
                    onPressed: _submitTask,
                    child: const Text("Add Task"),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _submitTask() {
    bool isValid = _formKey.currentState!.validate() &&
        priority.isNotEmpty &&
        status.isNotEmpty;
    if (isValid) {
      log("Priority , status , isComplete : $priority , $status , $isComplete");

      final task = TaskModel(
          id: generateUniqueTaskId(),
          title: _titleController.text.trim(),
          description: _descriptionController.text.trim(),
          status: status,
          priority: priority,
          dueDate: DateTime.now(),
          createdDate: DateTime.now(),
          updatedDate: DateTime.now(),
          isCompleted: isComplete);
      log("Create Btn FInal Data :${task.toJson()}");
      ref.watch(apiControllerProvider).create(task);
    } else {
      List messages = [];
      Map<String, dynamic> fieldValidations = {
        "priority": priority.isEmpty,
        "status": status.isEmpty
      };
      fieldValidations.forEach((key, value) {
        if (value) {
          messages.add(key);
        }
      });
      String requiredMsg = messages.join(", ");
      snackBarMsg("$requiredMsg is Required", color: Colors.red);
    }
  }

  @override
  void dispose() {
    _titleController.clear();
    _descriptionController.clear();
    _selectedDateController.clear();
    super.dispose();
  }
}
