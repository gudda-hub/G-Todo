import '../export.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<dynamic> navigateTo(Widget widget) {
  return navigatorKey.currentState!
      .push(MaterialPageRoute(builder: (context) => widget));
}

navigatePop() {
  return navigatorKey.currentState!.pop();
}

navigatePush(Widget widget) {
  return navigatorKey.currentState!
      .push(MaterialPageRoute(builder: (context) => widget));
}

navigatePushReplacement(Widget widget) {
  return navigatorKey.currentState!
      .pushReplacement(MaterialPageRoute(builder: (context) => widget));
}

navigatePopUntil(Widget widget) {
  return navigatorKey.currentState!.popUntil(
      MaterialPageRoute(builder: (context) => widget) as RoutePredicate);
}

navigateToRemoveUntil(Widget widget) {
  return navigatorKey.currentState!.pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => widget),
      (Route<dynamic> route) => false);
}

void navigatePopUntill(String routeName) {
  return navigatorKey.currentState!.popUntil(ModalRoute.withName(routeName));
}
