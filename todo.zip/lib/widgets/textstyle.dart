import '../export.dart';

class TxtStyle {
  // Heading style
  TextStyle heading() {
    return const TextStyle(
      fontSize: 24, // Large size for headings
      fontWeight: FontWeight.bold,
      color: Colors.black, // Default black color
    );
  }

  // Subheading style
  TextStyle subHeading() {
    return const TextStyle(
      fontSize: 20, // Slightly smaller than heading
      fontWeight: FontWeight.w600,
      color: Colors.black87, // Slightly lighter black
    );
  }

  // Normal text style
  TextStyle normal() {
    return const TextStyle(
      fontSize: 16, // Regular text size
      fontWeight: FontWeight.normal,
      color: Colors.black54, // Medium black color
    );
  }

  // Caption style
  TextStyle caption() {
    return const TextStyle(
      fontSize: 12, // Small size for captions
      fontWeight: FontWeight.w400,
      color: Colors.grey, // Grey for subtle captions
    );
  }

  // Button text style
  TextStyle btn() {
    return const TextStyle(
      fontSize: 16, // Same size as normal but bold
      fontWeight: FontWeight.bold,
      color: Colors.white, // White color for buttons
    );
  }
}
