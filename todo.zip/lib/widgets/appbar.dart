import '../../export.dart';

class BaseAppBar extends StatelessWidget implements PreferredSizeWidget {
  final double? elevation;
  final bool? boolLeading, centerTitle, actions;
  final Widget? leading, titleWidget;
  final Function? onTap;
  final String? title;
  final List<Widget>? actionList;
  final Color? bgColor, txtColor;
  final AppBar appBar = AppBar();
  BaseAppBar(
      {super.key,
      this.boolLeading,
      this.elevation,
      this.actions,
      this.leading,
      this.centerTitle,
      this.onTap,
      this.title,
      this.titleWidget,
      this.bgColor,
      this.txtColor,
      this.actionList});

  @override
  Size get preferredSize => Size.fromHeight(appBar.preferredSize.height);

  @override
  Widget build(BuildContext context) {
    return AppBar(
        backgroundColor: bgColor,
        elevation: elevation,
        automaticallyImplyLeading: boolLeading ?? true,
        leading: leading,
        title: titleWidget ??
            Text(title ?? '',
                style: TextStyle(
                    color: txtColor ?? Colors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w600)),
        centerTitle: centerTitle ?? true,
        actions: actionList);
  }
}
