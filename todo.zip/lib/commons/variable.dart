class DbUrls {
  static String deviceToken = 'deviceToken';
  static String task = 'userTask';
}
